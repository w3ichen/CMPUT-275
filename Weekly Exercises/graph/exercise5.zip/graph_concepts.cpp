// A template for the Graph Concepts Exercise in C++.

#include <iostream>
using namespace std;

int count_components(Digraph* g) {
    return 0;
}


Digraph* read_city_graph_undirected(char filename[]) {
        
}


int main(int argc, char *argv[]) {

    return 0;
}