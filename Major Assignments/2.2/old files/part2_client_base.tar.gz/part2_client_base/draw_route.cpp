#include "draw_route.h"
#include "map_drawing.h"

extern shared_vars shared;

void draw_route() {
  // implement this!
}
